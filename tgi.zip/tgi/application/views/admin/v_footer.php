<footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="">Roni Setyanto </a>Siskom Unsa.</strong> All rights reserved.
  </footer>